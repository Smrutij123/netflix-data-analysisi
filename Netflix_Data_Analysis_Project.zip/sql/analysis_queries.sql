-- ==========================================
-- NETFLIX DATA ANALYSIS SQL SCRIPT
-- ==========================================

-- 1. Count of Movies vs TV Shows
SELECT type, COUNT(*) AS total_count
FROM netflix_titles
GROUP BY type;

-- 2. Top 10 Countries by Content Production
SELECT country, COUNT(*) AS total_titles
FROM netflix_titles
GROUP BY country
ORDER BY total_titles DESC
LIMIT 10;

-- 3. Average IMDB Rating by Genre
SELECT listed_in, ROUND(AVG(imdb_rating), 2) AS avg_imdb, COUNT(*) AS title_count
FROM netflix_titles
GROUP BY listed_in
ORDER BY avg_imdb DESC;

-- 4. Top 10 Most Viewed Titles
SELECT title, type, country, views_millions, imdb_rating
FROM netflix_titles
ORDER BY views_millions DESC
LIMIT 10;

-- 5. Yearly Content Addition Trend
SELECT release_year_added, COUNT(*) AS titles_added
FROM netflix_titles
GROUP BY release_year_added
ORDER BY release_year_added;
