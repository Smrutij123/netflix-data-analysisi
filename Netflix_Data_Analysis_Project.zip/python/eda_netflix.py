# ==========================================
# NETFLIX EXPLORATORY DATA ANALYSIS (EDA)
# ==========================================

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set visual style
sns.set_theme(style="whitegrid")

# 1. Load Dataset
df = pd.read_csv('../data/netflix_cleaned.csv')
print("Dataset Shape:", df.shape)
print(df.head())

# 2. Basic Data Overview & Missing Values
print("\n--- Missing Values ---")
print(df.isnull().sum())

print("\n--- Summary Statistics ---")
print(df.describe())

# 3. Visualization 1: Content Type Distribution
plt.figure(figsize=(6, 4))
sns.countplot(x='type', data=df, palette='Set2')
plt.title('Distribution of Movies vs TV Shows')
plt.xlabel('Content Type')
plt.ylabel('Count')
plt.savefig('content_type_distribution.png', bbox_inches='tight')
plt.close()

# 4. Visualization 2: Top Genres by Average IMDB Rating
plt.figure(figsize=(10, 5))
genre_ratings = df.groupby('listed_in')['imdb_rating'].mean().reset_index().sort_values(by='imdb_rating', ascending=False)
sns.barplot(x='imdb_rating', y='listed_in', data=genre_ratings, palette='viridis')
plt.title('Average IMDB Rating by Genre')
plt.xlabel('Average IMDB Rating')
plt.ylabel('Genre')
plt.savefig('genre_ratings.png', bbox_inches='tight')
plt.close()

print("\nEDA Completed Successfully! Visualizations saved.")
