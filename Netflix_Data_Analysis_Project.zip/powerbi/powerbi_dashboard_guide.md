# Power BI Dashboard Implementation Guide

## 1. Data Connection
- Open Power BI Desktop.
- Click **Get Data** -> **Text/CSV** and select `data/netflix_cleaned.csv`.
- Click **Transform Data** to open Power Query Editor. Ensure data types are correct (e.g., `release_year` as Whole Number, `imdb_rating` as Decimal).

## 2. Recommended Pages & Layout
### Page 1: Executive Overview (Dashboard)
- **KPI Cards:** Total Titles, Total Views (Millions), Average IMDB Rating, Total Countries.
- **Donut Chart:** Content Distribution (Movies vs. TV Shows).
- **Bar Chart:** Top 10 Countries by Content Count.
- **Line Chart:** Content Additions Over Time (`release_year_added`).

### Page 2: Content & Ratings Analysis
- **Clustered Bar Chart:** Average IMDB Rating by Genre (`listed_in`).
- **Matrix / Table:** Top 10 Most Viewed Titles with columns for Title, Type, Genre, Country, Views, and IMDB Rating.
- **Slicers:** Country, Release Year, Content Rating (TV-MA, PG-13, etc.).

## 3. Key DAX Measures
```dax
Total Titles = COUNT(netflix_cleaned[show_id])

Total Views (M) = SUM(netflix_cleaned[views_millions])

Avg IMDB = AVERAGE(netflix_cleaned[imdb_rating])

Movie Count = CALCULATE([Total Titles], netflix_cleaned[type] = "Movie")

TV Show Count = CALCULATE([Total Titles], netflix_cleaned[type] = "TV Show")
```
